<chapter name="item.stoneGearItem.name"/>
<lore>
事实证明木头难以用来做正二八经的机器，因此你决定用石头制作新的齿轮。
对比木齿轮，它另外一个优点是根本不会着火。
</lore>
<no_lore>
石齿轮本质上其实是木齿轮的升级版本。由于石头的硬度，它可用于制造更强大的机器。
</no_lore>
<recipes_usages stack="buildcraftcore:gear_stone"/>
